import 'dart:io';

void areaRetangulo() {
  print("Digite a base:");
  double base = double.parse(stdin.readLineSync()!);

  print("Digite a altura:");
   double altura = double.parse(stdin.readLineSync()!);
  print("A área é:");
   print(base * altura);
}