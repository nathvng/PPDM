import 'dart:io';

void compararNumero () {
  print("Digite o primeiro número:");
  int numero = int.parse(stdin.readLineSync()!);

  print("Digite o segundo número:");
  int numero2 = int.parse(stdin.readLineSync()!);

   if(numero > numero2){
    print("$numero mair que $numero2");
  } else if(numero2 > numero){
    print("$numero menor que $numero2");
  }else{
    print("os números são iguais");
  }
 }
