import 'dart:io';

void classificacaoNota() {
  print("Digite sua nota:");
  int nota = int.parse(stdin.readLineSync()!);

  if(nota >= 90 &&  nota <= 100 ){
   print("Sua classificação é A");
  }
  else if (nota >= 80 &&  nota <= 89 ){
   print("Sua classificação é B");
  }
  else if (nota >= 70 &&  nota <= 79 ){
   print("Sua classificação é C");
  }
  else if (nota >= 60 &&  nota <= 69 ){
   print("Sua classificação é D");
  }
  else{
    print("Nota inferior a 60");
  }
 }