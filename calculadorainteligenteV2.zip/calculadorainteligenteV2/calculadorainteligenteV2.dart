import 'dart:io';
import 'exercicios/barrel.dart';

void exibirMenu() {
print('''
1-Exibir olá, Darrt!
2-Calcular a área de um retângulo
3-Verificar se um número é par ou ímpar
4-Comparar dois números
5-Converter nota para conceito
6-Exibir contagem progressiva
7-Somar todos os números até um valor específicado
8-Exibir a tabuada de um número
"9-sair do programa
''');
}

void main(){
int escolha;

do{
exibirMenu();
stdout.write("Escolha uma opção: ");
escolha = int.parse(stdin.readLineSync()!);

print("");

  switch (escolha) {
    case 1: olaDart();break;
    case 2: areaRetangulo();break;
    case 3: parImpar();break;
    case 4: compararNumero();break;
    case 5: classificacaoNota();break;
    case 6: contagem();break;
    case 7: somaTodos();break;
    case 8: tabuadaAutomatica();break;
    case 9:
  print("Sair do programa");
   break;
    default:
    print("Opção inválida");
    }
}while(escolha !=9);
}